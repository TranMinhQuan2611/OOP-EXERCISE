

public class TestShape {
public static void main(String[] args) {
	Circle c1= new Circle("Red", false, 4);
	System.out.println(c1);
	Square s1= new Square(4, "Yellow", true);
	System.out.println(s1);
}
}
