

public class TestPerson {
public static void main(String[] args) {
	Person p1= new Student("Nguyen Van A","12 Le Loi","IT",2024,8500000);
	Person p2=new Staff("Nguyen Van B","Tran Dai Nghia","VKU", 10000000);
	System.out.println(p1);
	System.out.println(p2);
}
}
