

public class TestGeometricObject {
public static void main(String[] args) {
	Circle c2= new Circle(3);
	System.out.println(c2);
	Rectangle r2= new Rectangle(3, 4);
	System.out.println(r2);
	System.out.println(r2.getArea());
}
}
